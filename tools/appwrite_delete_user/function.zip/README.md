# Appwrite Account Deletion Worker

This small Node.js worker processes documents in the `account_deletion_requests` collection and performs complete user data removal using an Appwrite admin API key.

How it works

- The client creates a document in `account_deletion_requests` with `user_id` and `status: pending`.
- This worker lists pending requests, deletes related documents and storage files, and then deletes the Appwrite user using the admin key.
- The worker updates the request document with `status` changes (`processing`, `done`, `failed`).

Setup

1. Copy `.env.example` to `.env` and populate variables.
2. Install dependencies:

```bash
npm install
```

3. Run the worker manually or set up a cron/job system:

```bash
node send_delete_requests.js
```

Environment variables

- `APPWRITE_ENDPOINT` - e.g. `https://sgp.cloud.appwrite.io/v1`
- `APPWRITE_PROJECT_ID` - your Appwrite project id
- `APPWRITE_API_KEY` - server API key with admin permissions
- `APPWRITE_DATABASE_ID` - database id (optional)
- `APPWRITE_REQUESTS_COLLECTION` - collection id for account deletion requests (defaults to `account_deletion_requests`)
- Optional overrides for collection/bucket names (see script).

Security

- Ensure `APPWRITE_API_KEY` is kept secret and not checked into source.
- Run this worker on a secure server or deploy as an Appwrite Cloud Function with the admin key set in environment variables.

Notes

- This script is best deployed as an Appwrite Cloud Function with admin credentials injected as secrets, or run via a secure VM.
- Update the list of collections/buckets to match your Appwrite project schema if names differ.
