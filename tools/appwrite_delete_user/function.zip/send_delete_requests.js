require('dotenv').config();
const sdk = require('node-appwrite');
const fs = require('fs');

const APPWRITE_ENDPOINT = process.env.APPWRITE_ENDPOINT;
const APPWRITE_PROJECT = process.env.APPWRITE_PROJECT_ID;
const APPWRITE_KEY = process.env.APPWRITE_API_KEY; // Server/API key with admin privileges
const DATABASE_ID = process.env.APPWRITE_DATABASE_ID || process.env.APPWRITE_FUNCTION_DATABASE_ID || 'default';
const REQUESTS_COLLECTION = process.env.APPWRITE_REQUESTS_COLLECTION || 'account_deletion_requests';

if (!APPWRITE_ENDPOINT || !APPWRITE_PROJECT || !APPWRITE_KEY) {
  console.error('Missing Appwrite configuration in environment');
  // Continue; Appwrite Cloud Functions will inject environment variables at runtime.
}

// Initialize Appwrite client with admin key
const client = new sdk.Client()
  .setEndpoint(APPWRITE_ENDPOINT)
  .setProject(APPWRITE_PROJECT)
  .setKey(APPWRITE_KEY);

const databases = new sdk.Databases(client);
const storage = new sdk.Storage(client);
const usersService = sdk.Users ? new sdk.Users(client) : null;

async function fetchPendingRequests(limit = 100) {
  try {
    const resp = await databases.listDocuments(DATABASE_ID, REQUESTS_COLLECTION, [sdk.Query.equal('status', 'pending'), sdk.Query.limit(limit)]);
    return resp.documents || [];
  } catch (e) {
    console.error('Error fetching deletion requests:', e);
    return [];
  }
}

async function markRequest(id, updates) {
  try {
    await databases.updateDocument(DATABASE_ID, REQUESTS_COLLECTION, id, updates);
  } catch (e) {
    console.error('Failed to update request', id, e);
  }
}

async function deleteUserRelatedData(userId) {
  console.log('Processing deletion for user:', userId);

  try {
    // 1) Delete user profile document if exists
    try {
      await databases.deleteDocument(DATABASE_ID, process.env.APPWRITE_USERS_COLLECTION || 'user_profiles', userId);
      console.log('Deleted user profile document');
    } catch (e) {
      console.warn('User profile delete may have failed or not exist:', e.message || e);
    }

    // 2) Delete user progress, achievements, notifications, follows, messages, settings
    const collectionsToPurge = [
      process.env.APPWRITE_PROGRESS_COLLECTION || 'user_progress',
      process.env.APPWRITE_USER_ACHIEVEMENTS_COLLECTION || 'user_achievements',
      process.env.APPWRITE_NOTIFICATIONS_COLLECTION || 'notifications',
      process.env.APPWRITE_FOLLOWS_COLLECTION || 'follows',
      process.env.APPWRITE_MESSAGES_COLLECTION || 'messages',
      process.env.APPWRITE_USER_SETTINGS_COLLECTION || 'user_settings',
      process.env.APPWRITE_PUSH_TOKENS_COLLECTION || 'push_tokens',
    ];

    for (const col of collectionsToPurge) {
      try {
        const res = await databases.listDocuments(DATABASE_ID, col, [sdk.Query.equal('user_id', userId), sdk.Query.limit(100)]);
        if (res.documents && res.documents.length) {
          for (const doc of res.documents) {
            try {
              await databases.deleteDocument(DATABASE_ID, col, doc.$id);
            } catch (e) {
              console.warn(`Failed to delete document ${doc.$id} in ${col}:`, e.message || e);
            }
          }
        }
      } catch (e) {
        console.warn(`Failed to list documents in ${col}:`, e.message || e);
      }
    }

    // 3) Attempt to delete profile image in storage (assumes fileId == userId)
    const profileBucket = process.env.APPWRITE_PROFILE_BUCKET || 'profile_images';
    try {
      await storage.deleteFile(profileBucket, userId);
      console.log('Deleted profile image:', userId);
    } catch (e) {
      console.warn('Profile image delete may have failed or not exist:', e.message || e);
    }

    // 4) Delete FCM tokens (already attempted in collections above)

    // 5) Attempt to delete the user account via Admin Users endpoint
    try {
      if (usersService && typeof usersService.delete === 'function') {
        await usersService.delete(userId);
        console.log('Deleted user via Users.delete');
      } else {
        // Fallback to direct HTTP call
        await client.call('delete', `/v1/users/${userId}`, {
          'content-type': 'application/json'
        }, []);
        console.log('Deleted user via client.call');
      }
    } catch (e) {
      console.warn('Failed to delete Appwrite user (may require different API):', e.message || e);
    }

    return true;
  } catch (e) {
    console.error('Error while deleting user data for', userId, e);
    return false;
  }
}

async function run() {
  // If running as Appwrite Cloud Function, attempt to read the event payload
  const eventDataRaw = process.env.APPWRITE_FUNCTION_EVENT_DATA;
  if (eventDataRaw) {
    try {
      const event = JSON.parse(eventDataRaw);
      // Event may include the document data under data or root
      const doc = event && (event.data || event);
      const reqId = doc.$id || doc['$id'];
      const userId = doc.user_id || doc.userId || (doc.data && doc.data.user_id) || (doc.data && doc.data.userId);

      if (!reqId) {
        console.error('Event missing request id');
        return;
      }

      await markRequest(reqId, { status: 'processing', processing_at: Date.now() });

      if (!userId) {
        await markRequest(reqId, { status: 'failed', error: 'missing_user_id' });
        console.error('Request missing user_id', reqId);
        return;
      }

      const ok = await deleteUserRelatedData(userId);
      if (ok) {
        await markRequest(reqId, { status: 'done', completed_at: Date.now() });
        console.log('Completed deletion for', userId);
      } else {
        await markRequest(reqId, { status: 'failed', error: 'processing_error' });
        console.log('Failed deletion for', userId);
      }
      return;
    } catch (e) {
      console.error('Failed to parse APPWRITE_FUNCTION_EVENT_DATA', e);
    }
  }

  // Fallback: poll pending requests (for local/manual runs)
  console.log('Fetching pending account deletion requests...');
  const requests = await fetchPendingRequests(200);
  console.log(`Found ${requests.length} requests`);

  for (const req of requests) {
    const userId = req.user_id || req.userId || req.user_id;
    if (!userId) {
      await markRequest(req.$id, { status: 'failed', error: 'missing_user_id' });
      continue;
    }

    await markRequest(req.$id, { status: 'processing', processing_at: Date.now() });

    const ok = await deleteUserRelatedData(userId);

    if (ok) {
      await markRequest(req.$id, { status: 'done', completed_at: Date.now() });
      console.log('Completed deletion for', userId);
    } else {
      await markRequest(req.$id, { status: 'failed', error: 'processing_error' });
      console.log('Failed deletion for', userId);
    }
  }
}

if (require.main === module) {
  run().catch(e => console.error(e));
}

module.exports = { run };
