require('dotenv').config();
const { run } = require('./send_delete_requests');

(async () => {
  try {
    await run();
  } catch (e) {
    console.error(e);
    process.exit(1);
  }
})();
