Deployment guide — Appwrite Cloud Function

This worker deletes all user-related data when a deletion request document is created. You can deploy it as a secure Appwrite Cloud Function (recommended) or run it on a server/cron.

Prepare

1. Copy `.env.example` to `.env` and fill values (do NOT commit `.env`).
2. Ensure `APPWRITE_API_KEY` is a server API key with admin permissions (delete documents, delete users, delete storage files).

Local test

```bash
cd tools/appwrite_delete_user
npm install
node index.js
```

Deploy as Appwrite Cloud Function (Console)

1. Create the tar.gz package of the function code (include `index.js`, `send_delete_requests.js`, `package.json`, `README.md`, `.env` NOT included).

```bash
cd tools/appwrite_delete_user
tar -czf function.tar.gz index.js send_delete_requests.js package.json README.md .env.example
```

2. Open Appwrite Console → Functions → Create Function.
   - Runtime: `node-16` (or supported Node.js runtime)
   - Entry point: `index.js`
   - Upload `function.tar.gz` as the deployment package.

3. Set environment variables (secrets): `APPWRITE_ENDPOINT`, `APPWRITE_PROJECT_ID`, `APPWRITE_API_KEY`, `APPWRITE_DATABASE_ID`, `APPWRITE_REQUESTS_COLLECTION`, and any collection/bucket overrides used in `.env.example`.

4. Set triggers (Events) so function runs automatically when a document is created in the requests collection. Use event pattern:

```
databases.${APPWRITE_DATABASE_ID}.collections.${APPWRITE_REQUESTS_COLLECTION}.documents.create
```

5. Optionally: add a schedule trigger (cron) to retry or process missed requests periodically.

6. Deploy and enable the function.

Testing via app

- From the app, trigger account deletion (the client creates a document in `account_deletion_requests`).
- Confirm the function executed and updated the request document status to `processing` → `done`.

Safety & notes

- Use staging project for initial tests.
- Consider adding a short delay/grace period before deletion.
- Keep `APPWRITE_API_KEY` secret and rotate if compromised.
- For high volume, paginate and batch deletes in the worker and add retry/backoff.
