const { run } = require('./send_delete_requests');

module.exports = async function() {
  try {
    const result = await run();
    // For Appwrite HTTP functions the runtime captures stdout. Log JSON result for debugging.
    console.log('Function result:', JSON.stringify(result));
    if (result && result.success) return;
    // Exit with non-zero to indicate failure to the platform.
    throw new Error(result && result.error ? result.error : 'deletion_failed');
  } catch (e) {
    console.error(e);
    throw e;
  }
};
