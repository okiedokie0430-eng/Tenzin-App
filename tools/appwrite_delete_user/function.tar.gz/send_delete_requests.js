// New HTTP-friendly implementation
const ENDPOINT = process.env.APPWRITE_FUNCTION_ENDPOINT || 'https://sgp.cloud.appwrite.io/v1';
const PROJECT = process.env.APPWRITE_FUNCTION_PROJECT_ID || process.env.APPWRITE_PROJECT_ID || process.env.APPWRITE_PROJECT || '69536e3f003c0ac930bd';
const DB = process.env.APPWRITE_FUNCTION_DATABASE_ID || process.env.APPWRITE_DATABASE_ID || 'collection';
const ADMIN_KEY = process.env.APPWRITE_ADMIN_KEY || process.env.ADMIN_KEY || process.env.APPWRITE_API_KEY || '';

const COLLECTIONS_TO_SCAN = [
  'user_progress',
  'user_achievements',
  'notifications',
  'push_tokens',
  'follows',
  'messages',
  'user_settings'
];

async function httpJson(path, method = 'GET', body = null, extraHeaders = {}) {
  const url = `${ENDPOINT}${path}`;
  const headers = Object.assign({
    'X-Appwrite-Project': PROJECT,
    'X-Appwrite-Key': ADMIN_KEY,
  }, extraHeaders);

  const opts = { method, headers };
  if (body !== null) {
    headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }

  const res = await fetch(url, opts);
  const text = await res.text();
  try { return JSON.parse(text); } catch { return text; }
}

async function listDocuments(collectionId, limit = 100, offset = 0) {
  const path = `/databases/${DB}/collections/${collectionId}/documents?limit=${limit}&offset=${offset}`;
  try {
    const json = await httpJson(path, 'GET');
    return Array.isArray(json.documents) ? json.documents : [];
  } catch (err) {
    console.warn(`List docs failed for ${collectionId}: ${err}`);
    return [];
  }
}

async function deleteDocument(collectionId, documentId) {
  const path = `/databases/${DB}/collections/${collectionId}/documents/${documentId}`;
  try {
    await httpJson(path, 'DELETE');
    console.log(`Deleted document ${documentId} from ${collectionId}`);
  } catch (err) {
    console.warn(`Failed to delete doc ${documentId} in ${collectionId}: ${err}`);
  }
}

async function deleteUserFiles(userId) {
  const bucket = process.env.APPWRITE_PROFILE_BUCKET || 'profile_images';
  const path = `/storage/buckets/${bucket}/files/${userId}`;
  try {
    await httpJson(path, 'DELETE');
    console.log(`Deleted storage file ${userId} in bucket ${bucket}`);
  } catch (err) {
    console.warn(`No storage file or failed delete for ${userId} in ${bucket}: ${err}`);
  }
}

async function deleteUserAccount(userId) {
  const path = `/users/${userId}`;
  try {
    await httpJson(path, 'DELETE');
    console.log(`Deleted Appwrite user ${userId}`);
  } catch (err) {
    console.warn(`Failed to delete Appwrite user ${userId}: ${err}`);
  }
}

async function deleteUserRelatedData(userId) {
  for (const col of COLLECTIONS_TO_SCAN) {
    let offset = 0;
    while (true) {
      const docs = await listDocuments(col, 100, offset);
      if (!docs || docs.length === 0) break;
      for (const d of docs) {
        try {
          const owner = d.data && (d.data.userId || d.data.owner || d.data.user || d.data.user_id);
          if (owner === userId) {
            await deleteDocument(col, d.$id);
          }
        } catch (err) {
          console.warn(`Error processing doc ${d.$id} in ${col}: ${err}`);
        }
      }
      if (docs.length < 100) break;
      offset += docs.length;
    }
  }
  await deleteUserFiles(userId);
  await deleteUserAccount(userId);
}

async function run() {
  // Determine userId: prefer APPWRITE_FUNCTION_DATA JSON -> APPWRITE_FUNCTION_USER_ID
  let userId = null;
  const raw = process.env.APPWRITE_FUNCTION_DATA || process.env.APPWRITE_FUNCTION_EVENT_DATA || null;
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      userId = parsed && (parsed.userId || parsed.user_id || parsed.user);
    } catch (e) {
      // not JSON, ignore
    }
  }
  if (!userId && process.env.APPWRITE_FUNCTION_USER_ID) {
    userId = process.env.APPWRITE_FUNCTION_USER_ID;
  }

  if (!userId) {
    console.error('No userId provided. Provide as APPWRITE_FUNCTION_DATA or execute as authenticated user.');
    return { success: false, error: 'missing_userId' };
  }

  if (!ADMIN_KEY) {
    console.error('No ADMIN_KEY found in env. Set function secret APPWRITE_ADMIN_KEY or ADMIN_KEY.');
    return { success: false, error: 'missing_admin_key' };
  }

  try {
    await deleteUserRelatedData(userId);
    return { success: true };
  } catch (e) {
    console.error('Deletion failed', e);
    return { success: false, error: e && e.message };
  }
}

module.exports = { run, deleteUserRelatedData };
